%%
clear all;close all;clc
dataFolder = fullfile('D:\Deep Learning\Matlab2020b\Breathing Sounds for COVID-19\Data2');
ads = audioDatastore(fullfile(dataFolder, 'Data'), ...
    'IncludeSubfolders',true, ...
    'FileExtensions','.wav', ...
    'LabelSource','foldernames');
%%
datafolder_scallogram = "structure_Scallogram";
catego=categories(ads.Labels);
for i = 1:1:length(catego)
    imgLoc = fullfile(datafolder_scallogram,char(catego{i}));
    mkdir(imgLoc)
end
%%
Fs = 44100;
sig = audioread(ads.Files{1});
fb = cwtfilterbank('SignalLength',length(sig),...
    'SamplingFrequency',Fs,...
    'VoicesPerOctave',4);
[cfs,frq] = wt(fb,sig);
t = (0:length(sig)-1)/Fs;figure;pcolor(t,frq,abs(cfs))
set(gca,'yscale','log');shading interp;axis tight;
title('Scalogram');xlabel('Time (s)');ylabel('Frequency (Hz)')
%%
helperCreateRGBfromTF(ads,datafolder_scallogram)
%%

%%
function helperCreateRGBfromTF(ads,datafolder_scallogram)

for i = 1:length(ads.Files)
    try
        clearvars sig
        Fs = 44100;
        %Fs = 16000;
        sig = audioread(ads.Files{i});
        %ads.Files{i}
        fb = cwtfilterbank('SignalLength',length(sig),...
        'SamplingFrequency',Fs,...
        'VoicesPerOctave',4);
        cfs = abs(fb.wt(sig(:)));
        im = ind2rgb(im2uint8(rescale(cfs)),jet(128));   
        imgLoc = fullfile(datafolder_scallogram,char(ads.Labels(i)));
        imFileName = strcat(char(ads.Labels(i)),'_',num2str(i),'.jpg');
        imwrite(imresize(im,[224 224]),fullfile(imgLoc,imFileName));
    catch
        fprintf('Inconsistent data in iteration %s, skipped.\n', ads.Files{i});
    end
end
end

