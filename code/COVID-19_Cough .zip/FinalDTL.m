clear all;close all;clc
%%
val=1;
%["googlenet" "squeezenet" "resnet18" "resnet50" 
%"mobilenetv2" "resnet101" "inceptionv3" 
%"inceptionresnetv2"]
networkName='resnet18';
pixelRange = [-30 30];
%'sgdm' | 'rmsprop' | 'adam'
Solver = 'adam';
LR=1e-4;
MiniBatchSize=16;
MaxEpochs=1;

%%
if val==0
    split=0.7;
    split_method='randomized';
    digitDatasetPath1 = fullfile('D:\Deep Learning\Matlab\Transfer-Learning-using-Matlab-master\data\MerchData');
    imds = imageDatastore(digitDatasetPath1, ...
        'IncludeSubfolders',true, ...
        'LabelSource','foldernames');
    [imdsTrain,imdsValidation] = splitEachLabel(imds,split,split_method);
    imdsTest=imds;
elseif val==1
    digitDatasetPath1 = fullfile('D:\Deep Learning\Matlab\Covid 19\CT\Dataset+GAN+Augment\COVID-19\train');
    digitDatasetPath2 = fullfile('D:\Deep Learning\Matlab\Covid 19\CT\Dataset+GAN+Augment\COVID-19\val');
    digitDatasetPath3 = fullfile('D:\Deep Learning\Matlab\Covid 19\CT\Dataset+GAN+Augment\COVID-19\test');
    imdsTrain=imageDatastore(digitDatasetPath1, ...
        'IncludeSubfolders',true, ...
        'LabelSource','foldernames');
    imdsValidation=imageDatastore(digitDatasetPath2, ...
        'IncludeSubfolders',true, ...
        'LabelSource','foldernames');
    imdsTest=imageDatastore(digitDatasetPath3, ...
        'IncludeSubfolders',true, ...
        'LabelSource','foldernames');
end
%%
switch networkName
    case "alexnet"
        net = alexnet;
    case "vgg16"
        net = vgg16;
    case "vgg19"
        net = vgg19;
    case "squeezenet"
        net = squeezenet;
    case "googlenet"
        net = googlenet;
    case "resnet18"
        net = resnet18;
    case "mobilenetv2"
        net = mobilenetv2;
    case "resnet50"
        net = resnet50;
    case "resnet101"
        net = resnet101;
    case "inceptionv3"
        net = inceptionv3;
    case "inceptionresnetv2"
        net = inceptionresnetv2;
    case "nasnetmobile"
        net = nasnetmobile;
    case "densenet201"
        net = densenet201;
    otherwise
        msg = ['Undefined network selection. ' ...
            'Options are "default", "googlenet", and "resnet18".'];
        error(msg);
end
inputSize = net.Layers(1).InputSize;
%%
if isa(net,'SeriesNetwork')
    lgraph = layerGraph(net.Layers);
else
    lgraph = layerGraph(net);
end

[learnableLayer,classLayer] = findLayersToReplace(lgraph);

numClasses = numel(categories(imdsTrain.Labels));

if isa(learnableLayer,'nnet.cnn.layer.FullyConnectedLayer')
    newLearnableLayer = fullyConnectedLayer(numClasses, ...
        'Name','new_fc', ...
        'WeightLearnRateFactor',10, ...
        'BiasLearnRateFactor',10);
elseif isa(learnableLayer,'nnet.cnn.layer.Convolution2DLayer')
    newLearnableLayer = convolution2dLayer(1,numClasses, ...
        'Name','new_conv', ...
        'WeightLearnRateFactor',10, ...
        'BiasLearnRateFactor',10);
end

lgraph = replaceLayer(lgraph,learnableLayer.Name,newLearnableLayer);

newClassLayer = classificationLayer('Name','new_classoutput');
lgraph = replaceLayer(lgraph,classLayer.Name,newClassLayer);

% layers = lgraph.Layers;
% connections = lgraph.Connections;
% layers(1:20) = freezeWeights(layers(1:20));
% lgraph = createLgraphUsingConnections(layers,connections);

%%
imageAugmenter = imageDataAugmenter( ...
    'RandXReflection',true, ...
    'RandXTranslation',pixelRange, ...
    'RandYTranslation',pixelRange);
% augimdsTrain = augmentedImageDatastore(inputSize(1:2),imdsTrain, ...
%     'DataAugmentation',imageAugmenter);
augimdsTrain = augmentedImageDatastore(inputSize(1:2),imdsTrain,'ColorPreprocessing','gray2rgb');
augimdsValidation = augmentedImageDatastore(inputSize(1:2),imdsValidation,'ColorPreprocessing','gray2rgb');
augimdsTest = augmentedImageDatastore(inputSize(1:2),imdsTest,'ColorPreprocessing','gray2rgb');
options = trainingOptions(Solver, ...
    'MiniBatchSize',MiniBatchSize, ...
    'MaxEpochs',MaxEpochs, ...
    'InitialLearnRate',LR, ...
    'ValidationData',augimdsValidation, ...
    'ValidationFrequency',2, ...
    'ValidationPatience',Inf, ...
    'Verbose',false, ...
    'Plots','training-progress');
%%
netTransfer = trainNetwork(augimdsTrain,lgraph,options);
%%
%Classify Test Images
[YPred,probs] = classify(netTransfer,augimdsTest);
accuracy = mean(YPred == imdsTest.Labels)

idx = randperm(numel(imdsTest.Files),4);
figure
for i = 1:4
    subplot(2,2,i)
    I = readimage(imdsTest,idx(i));
    imshow(I)
    label = YPred(idx(i));
    title(string(label) + ", " + num2str(100*max(probs(idx(i),:)),3) + "%");
end

figure
plotconfusion(imdsTest.Labels,YPred)

%%
[confMat,order] = confusionmat(imdsTest.Labels,YPred)
%%
%evaluation
%Evaluate(YValidation,YPred)
ACTUAL=imdsTest.Labels;
PREDICTED=YPred;
idx = (ACTUAL()=='COVID');
%disp(idx)
p = length(ACTUAL(idx));
n = length(ACTUAL(~idx));
N = p+n;
tp = sum(ACTUAL(idx)==PREDICTED(idx));
tn = sum(ACTUAL(~idx)==PREDICTED(~idx));
fp = n-tn;
fn = p-tp;

tp_rate = tp/p;
tn_rate = tn/n;

accuracy = (tp+tn)/N;
sensitivity = tp_rate;
specificity = tn_rate;
precision = tp/(tp+fp);
recall = sensitivity;
f_measure = 2*((precision*recall)/(precision + recall));
gmean = sqrt(tp_rate*tn_rate);

disp(['accuracy=' num2str(accuracy)])
disp(['sensitivity=' num2str(sensitivity)])
disp(['specificity=' num2str(specificity)])
disp(['precision=' num2str(precision)])
disp(['recall=' num2str(recall)])
disp(['f_measure=' num2str(f_measure)])
disp(['gmean=' num2str(gmean)])