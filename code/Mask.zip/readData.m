%%
%clear all;close all;clc
%% Load Data
%mask = load('gTruth1415.mat').gTruth;
%mask = gTruth;
%% Display first few rows of the data set.
mask(1:4,:)
%% Split the dataset into training, validation, and test sets. Select 70% of the data for training, 10% for validation, and the rest for testing the trained detector.
rng(0);
shuffledIndices = randperm(height(mask));
idx = floor(0.7 * length(shuffledIndices) );

trainingIdx = 1:idx;
trainingDataTbl = mask(shuffledIndices(trainingIdx),:);

validationIdx = idx+1 : idx + 1 + floor(0.1 * length(shuffledIndices) );
validationDataTbl = mask(shuffledIndices(validationIdx),:);

testIdx = validationIdx(end)+1 : length(shuffledIndices);
testDataTbl = mask(shuffledIndices(testIdx),:);
%% Use imageDatastore and boxLabelDatastore to create datastores for loading the image and label data during training and evaluation
imdsTrain = imageDatastore(trainingDataTbl{:,'imageFilename'});
bldsTrain = boxLabelDatastore(trainingDataTbl(:,'Mask'));

imdsValidation = imageDatastore(validationDataTbl{:,'imageFilename'});
bldsValidation = boxLabelDatastore(validationDataTbl(:,'Mask'));

imdsTest = imageDatastore(testDataTbl{:,'imageFilename'});
bldsTest = boxLabelDatastore(testDataTbl(:,'Mask'));
%% Combine image and box label datastores
%trainingData = combine(imdsTrain,bldsTrain);
%validationData = combine(imdsValidation,bldsValidation);
%testData = combine(imdsTest,bldsTest);