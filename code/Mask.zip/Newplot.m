% Plot Metrics
subplot(1,2,1);
plot(recall,precision);
xlabel('Recall');
ylabel('Precision');
title(sprintf('Average Precision = %.1f', ap))
grid on
subplot(1,2,2);
loglog(fppi, missRate);
xlabel('False Positives Per Image');
ylabel('Log Average Miss Rate');
title(sprintf('Log Average Miss Rate = %.1f', am))
grid on
%%
% [am, fppi, missRate] = evaluateDetectionMissRate(detectionResults, preprocessedTestData);
% figure;
% loglog(fppi, missRate);
% xlabel('False Positives Per Image');
% ylabel('Log Average Miss Rate');
% grid on
% title(sprintf('Log Average Miss Rate = %.1f', am))