%% Quick Test
% 100 50 31 
I = imread(testDataTbl.imageFilename{100});
I = imresize(I,inputSize(1:2));
[bboxes,scores] = detect(detector,I);
if(~isempty(bboxes))
    I = insertObjectAnnotation(I,'rectangle',bboxes,scores);
end
figure
imshow(I)
%%
I = imread(testDataTbl.imageFilename{31});
I = imresize(I,inputSize(1:2));
[bboxes,scores] = detect(detector,I);
if(~isempty(bboxes))
    I = insertObjectAnnotation(I,'rectangle',bboxes,scores);
end
figure
imshow(I)
%%
I = imread(testDataTbl.imageFilename{50});
I = imresize(I,inputSize(1:2));
[bboxes,scores] = detect(detector,I);
if(~isempty(bboxes))
    I = insertObjectAnnotation(I,'rectangle',bboxes,scores);
end
figure
imshow(I)
%%
I = imread(testDataTbl.imageFilename{55});
I = imresize(I,inputSize(1:2));
[bboxes,scores] = detect(detector,I);
if(~isempty(bboxes))
    I = insertObjectAnnotation(I,'rectangle',bboxes,scores);
end
figure
imshow(I)
%%
I = imread(testDataTbl.imageFilename{221});
I = imresize(I,inputSize(1:2));
[bboxes,scores] = detect(detector,I);
if(~isempty(bboxes))
    I = insertObjectAnnotation(I,'rectangle',bboxes,scores);
end
figure
imshow(I)

%%
I = imread(testDataTbl.imageFilename{98});
I = imresize(I,inputSize(1:2));
[bboxes,scores] = detect(detector,I);
if(~isempty(bboxes))
    I = insertObjectAnnotation(I,'rectangle',bboxes,scores);
end
figure
imshow(I)

