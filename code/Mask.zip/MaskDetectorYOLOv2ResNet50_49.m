%%
clear all;close all;clc
%% Load Data
mask = load('gTruth1415.mat').gTruth;
trainingData = load('trainingData.mat').trainingData;
validationData = load('validationData.mat').validationData;
testData = load('testData.mat').testData;
%% Display one of the training images and box labels.
data = read(trainingData);
I = data{1};
bbox = data{2};
annotatedImage = insertShape(I,'Rectangle',bbox);
annotatedImage = imresize(annotatedImage,2);
figure
imshow(annotatedImage)
%% Create a YOLO v2 Object Detection Network
inputSize = [224 224 3];
numClasses = width(mask)-1;
trainingDataForEstimation = transform(trainingData,@(data)preprocessData(data,inputSize));
numAnchors = 23;
[anchorBoxes, meanIoU] = estimateAnchorBoxes(trainingDataForEstimation, numAnchors)
featureExtractionNetwork = resnet50;
featureLayer = 'activation_49_relu';
lgraph = yolov2Layers(inputSize,numClasses,anchorBoxes,featureExtractionNetwork,featureLayer);
%% Data Augmentation
augmentedTrainingData = transform(trainingData,@augmentData);
% Visualize the augmented images.
augmentedData = cell(4,1);
for k = 1:4
    data = read(augmentedTrainingData);
    augmentedData{k} = insertShape(data{1},'Rectangle',data{2});
    reset(augmentedTrainingData);
end
figure
montage(augmentedData,'BorderSize',10)
%% Preprocess Training Data
preprocessedTrainingData = transform(augmentedTrainingData,@(data)preprocessData(data,inputSize));
preprocessedValidationData = transform(validationData,@(data)preprocessData(data,inputSize));
data = read(preprocessedTrainingData);
I = data{1};
bbox = data{2};
annotatedImage = insertShape(I,'Rectangle',bbox);
annotatedImage = imresize(annotatedImage,2);
figure
imshow(annotatedImage)
%% Train YOLO v2 Object Detector
options = trainingOptions('sgdm', ...
        'MiniBatchSize',32, ....
        'InitialLearnRate',1e-3, ...
        'MaxEpochs',1,...
        'CheckpointPath',tempdir, ...
        'ValidationData',preprocessedValidationData);

[detector,info] = trainYOLOv2ObjectDetector(preprocessedTrainingData,lgraph,options);
%% Training Loss for Each Iteration
figure
plot(info.TrainingLoss)
grid on
xlabel('Number of Iterations')
ylabel('Training Loss for Each Iteration')
%% Training Accuracy for Each Iteration
figure
plot(100-info.TrainingLoss)
grid on
xlabel('Number of Iterations')
ylabel('Training Accuracy for Each Iteration')
%% Evaluate Detector Using Test Set
preprocessedTestData = transform(testData,@(data)preprocessData(data,inputSize));
detectionResults = detect(detector, preprocessedTestData);
[ap,recall,precision] = evaluateDetectionPrecision(detectionResults, preprocessedTestData);
%fprintf('Recall = %.4f \nPrecision = %.4f \n', recall, precision);
figure
plot(recall,precision)
xlabel('Recall')
ylabel('Precision')
grid on
title(sprintf('Average Precision = %.2f',ap))
%% Evaluate and Plot the Miss Rate Results
[am, fppi, missRate] = evaluateDetectionMissRate(detectionResults, preprocessedTestData);
figure;
loglog(fppi, missRate);
xlabel('False Positives Per Image');
ylabel('Log Average Miss Rate');
grid on
title(sprintf('Log Average Miss Rate = %.1f', am))
%% Quick Test
% I = imread(testDataTbl.imageFilename{5});
% I = imresize(I,inputSize(1:2));
% [bboxes,scores] = detect(detector,I);
% if(~isempty(bboxes))
%     I = insertObjectAnnotation(I,'rectangle',bboxes,scores);
% end
% figure
% imshow(I)
%%
function B = augmentData(A)
% Apply random horizontal flipping, and random X/Y scaling. Boxes that get
% scaled outside the bounds are clipped if the overlap is above 0.25. Also,
% jitter image color.
B = cell(size(A));
I = A{1};
sz = size(I);
if numel(sz)==3 && sz(3) == 3
    I = jitterColorHSV(I,...
        'Contrast',0.2,...
        'Hue',0,...
        'Saturation',0.1,...
        'Brightness',0.2);
end
% Randomly flip and scale image.
tform = randomAffine2d('XReflection',true,'Scale',[1 1.1]);
rout = affineOutputView(sz,tform,'BoundsStyle','CenterOutput');
B{1} = imwarp(I,tform,'OutputView',rout);
% Apply same transform to boxes.
boxEstimate=round(A{2});
boxEstimate(:,1)=max(boxEstimate(:,1),1);
boxEstimate(:,2)=max(boxEstimate(:,2),1);
[B{2},indices] = bboxwarp(boxEstimate,tform,rout,'OverlapThreshold',0.25);
B{3} = A{3}(indices);
% Return original data only when all boxes are removed by warping.
if isempty(indices)
    B = A;
end
end

function data = preprocessData(data,targetSize)
% Resize image and bounding boxes to the targetSize.
scale = targetSize(1:2)./size(data{1},[1 2]);
data{1} = imresize(data{1},targetSize(1:2));
boxEstimate=round(data{2});
boxEstimate(:,1)=max(boxEstimate(:,1),1);
boxEstimate(:,2)=max(boxEstimate(:,2),1);
data{2} = bboxresize(boxEstimate,scale);
end